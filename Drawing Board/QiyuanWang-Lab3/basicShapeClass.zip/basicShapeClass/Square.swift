//
//  Square.swift
//  QiyuanWang-Lab3
//
//  Created by W Q on 10/4/22.
//

import UIKit

class Square: Shape {
    //var path = UIBezierPath()
    //var radius: CGFloat = 30.0;
    required init(origin: CGPoint, color: UIColor){
        //fatalError("IMPLEMENT THIS")
        super.init(origin: origin, color: color)
        self.kind = "square"
    }
    
    override func draw() {
        path.removeAllPoints()
        color.setFill()


        let rectLeng = 2.squareRoot() * radius
        path.append(UIBezierPath(rect: CGRect(x: origin.x - rectLeng/2 , y: origin.y - rectLeng/2, width: rectLeng, height: rectLeng)))
        // rotation need to be applied after shape is drawn
        shapeRotate(angle: angle)
        path.close()
        color.setStroke()
        path.stroke()
        
        path.fill()
    }
}

